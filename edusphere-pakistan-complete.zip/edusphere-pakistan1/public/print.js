window.onload=()=>window.print();
